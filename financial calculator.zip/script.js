// Tab switching functionality
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const tabName = this.getAttribute('data-tab');
        switchTab(tabName);
    });
});

function switchTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    // Remove active class from all buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected tab
    document.getElementById(tabName).classList.add('active');

    // Add active class to clicked button
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
}

// Simple Interest Calculator
function calculateSimpleInterest() {
    const principal = parseFloat(document.getElementById('si-principal').value);
    const rate = parseFloat(document.getElementById('si-rate').value);
    const time = parseFloat(document.getElementById('si-time').value);
    const resultDiv = document.getElementById('si-result');

    if (isNaN(principal) || isNaN(rate) || isNaN(time) || principal < 0 || rate < 0 || time < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    const simpleInterest = (principal * rate * time) / 100;
    const totalAmount = principal + simpleInterest;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Principal Amount</td>
                <td>$${principal.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Interest Rate</td>
                <td>${rate.toFixed(2)}% per annum</td>
            </tr>
            <tr>
                <td>Time Period</td>
                <td>${time.toFixed(2)} years</td>
            </tr>
            <tr>
                <td>Simple Interest</td>
                <td><strong>$${simpleInterest.toFixed(2)}</strong></td>
            </tr>
            <tr>
                <td>Total Amount</td>
                <td><strong>$${totalAmount.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// Compound Interest Calculator
function calculateCompoundInterest() {
    const principal = parseFloat(document.getElementById('ci-principal').value);
    const rate = parseFloat(document.getElementById('ci-rate').value);
    const time = parseFloat(document.getElementById('ci-time').value);
    const frequency = parseInt(document.getElementById('ci-frequency').value);
    const resultDiv = document.getElementById('ci-result');

    if (isNaN(principal) || isNaN(rate) || isNaN(time) || principal < 0 || rate < 0 || time < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    const amount = principal * Math.pow(1 + (rate / 100) / frequency, frequency * time);
    const compoundInterest = amount - principal;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Principal Amount</td>
                <td>$${principal.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Interest Rate</td>
                <td>${rate.toFixed(2)}% per annum</td>
            </tr>
            <tr>
                <td>Time Period</td>
                <td>${time.toFixed(2)} years</td>
            </tr>
            <tr>
                <td>Compounding Frequency</td>
                <td>${frequency} times per year</td>
            </tr>
            <tr>
                <td>Compound Interest</td>
                <td><strong>$${compoundInterest.toFixed(2)}</strong></td>
            </tr>
            <tr>
                <td>Total Amount</td>
                <td><strong>$${amount.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// EMI Calculator
function calculateEMI() {
    const principal = parseFloat(document.getElementById('emi-principal').value);
    const rate = parseFloat(document.getElementById('emi-rate').value);
    const months = parseInt(document.getElementById('emi-months').value);
    const resultDiv = document.getElementById('emi-result');

    if (isNaN(principal) || isNaN(rate) || isNaN(months) || principal < 0 || rate < 0 || months < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    if (months === 0) {
        showError(resultDiv, 'Loan tenure must be greater than 0');
        return;
    }

    const monthlyRate = rate / 100 / 12;
    let emi;

    if (monthlyRate === 0) {
        emi = principal / months;
    } else {
        emi = principal * (monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    }

    const totalPayment = emi * months;
    const totalInterest = totalPayment - principal;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Loan Amount</td>
                <td>$${principal.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Annual Interest Rate</td>
                <td>${rate.toFixed(2)}%</td>
            </tr>
            <tr>
                <td>Loan Tenure</td>
                <td>${months} months</td>
            </tr>
            <tr>
                <td>Monthly EMI</td>
                <td><strong>$${emi.toFixed(2)}</strong></td>
            </tr>
            <tr>
                <td>Total Interest Payable</td>
                <td>$${totalInterest.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Total Amount to Pay</td>
                <td><strong>$${totalPayment.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// ROI Calculator
function calculateROI() {
    const initialInvestment = parseFloat(document.getElementById('roi-initial').value);
    const finalValue = parseFloat(document.getElementById('roi-final').value);
    const time = parseFloat(document.getElementById('roi-time').value);
    const resultDiv = document.getElementById('roi-result');

    if (isNaN(initialInvestment) || isNaN(finalValue) || isNaN(time) || initialInvestment < 0 || finalValue < 0 || time < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    if (initialInvestment === 0) {
        showError(resultDiv, 'Initial investment must be greater than 0');
        return;
    }

    const profit = finalValue - initialInvestment;
    const roi = (profit / initialInvestment) * 100;
    const annualROI = time > 0 ? roi / time : 0;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Initial Investment</td>
                <td>$${initialInvestment.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Final Value</td>
                <td>$${finalValue.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Time Period</td>
                <td>${time.toFixed(2)} years</td>
            </tr>
            <tr>
                <td>Profit</td>
                <td>$${profit.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Total ROI</td>
                <td><strong>${roi.toFixed(2)}%</strong></td>
            </tr>
            <tr>
                <td>Annual ROI</td>
                <td><strong>${annualROI.toFixed(2)}% per year</strong></td>
            </tr>
        </table>
    `);
}

// Future Value Calculator
function calculateFutureValue() {
    const presentValue = parseFloat(document.getElementById('fv-pv').value);
    const rate = parseFloat(document.getElementById('fv-rate').value);
    const time = parseFloat(document.getElementById('fv-time').value);
    const resultDiv = document.getElementById('fv-result');

    if (isNaN(presentValue) || isNaN(rate) || isNaN(time) || presentValue < 0 || rate < 0 || time < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    const futureValue = presentValue * Math.pow(1 + (rate / 100), time);
    const interest = futureValue - presentValue;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Present Value</td>
                <td>$${presentValue.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Interest Rate</td>
                <td>${rate.toFixed(2)}% per annum</td>
            </tr>
            <tr>
                <td>Time Period</td>
                <td>${time.toFixed(2)} years</td>
            </tr>
            <tr>
                <td>Interest Earned</td>
                <td>$${interest.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Future Value</td>
                <td><strong>$${futureValue.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// Present Value Calculator
function calculatePresentValue() {
    const futureValue = parseFloat(document.getElementById('pv-fv').value);
    const rate = parseFloat(document.getElementById('pv-rate').value);
    const time = parseFloat(document.getElementById('pv-time').value);
    const resultDiv = document.getElementById('pv-result');

    if (isNaN(futureValue) || isNaN(rate) || isNaN(time) || futureValue < 0 || rate < 0 || time < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    if (rate === 0) {
        showError(resultDiv, 'Interest rate must be greater than 0');
        return;
    }

    const presentValue = futureValue / Math.pow(1 + (rate / 100), time);
    const discount = futureValue - presentValue;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Future Value</td>
                <td>$${futureValue.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Interest Rate</td>
                <td>${rate.toFixed(2)}% per annum</td>
            </tr>
            <tr>
                <td>Time Period</td>
                <td>${time.toFixed(2)} years</td>
            </tr>
            <tr>
                <td>Discount Amount</td>
                <td>$${discount.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Present Value</td>
                <td><strong>$${presentValue.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// Break-Even Calculator
function calculateBreakEven() {
    const fixedCosts = parseFloat(document.getElementById('be-fixed').value);
    const pricePerUnit = parseFloat(document.getElementById('be-price').value);
    const variableCost = parseFloat(document.getElementById('be-variable').value);
    const resultDiv = document.getElementById('be-result');

    if (isNaN(fixedCosts) || isNaN(pricePerUnit) || isNaN(variableCost) || 
        fixedCosts < 0 || pricePerUnit < 0 || variableCost < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    const contribution = pricePerUnit - variableCost;

    if (contribution <= 0) {
        showError(resultDiv, 'Price per unit must be greater than variable cost per unit');
        return;
    }

    const breakEvenUnits = fixedCosts / contribution;
    const breakEvenRevenue = breakEvenUnits * pricePerUnit;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Fixed Costs</td>
                <td>$${fixedCosts.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Price Per Unit</td>
                <td>$${pricePerUnit.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Variable Cost Per Unit</td>
                <td>$${variableCost.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Contribution Margin</td>
                <td>$${contribution.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Break-Even Units</td>
                <td><strong>${Math.ceil(breakEvenUnits)} units</strong></td>
            </tr>
            <tr>
                <td>Break-Even Revenue</td>
                <td><strong>$${breakEvenRevenue.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// Depreciation Calculator
function calculateDepreciation() {
    const cost = parseFloat(document.getElementById('dep-cost').value);
    const salvage = parseFloat(document.getElementById('dep-salvage').value);
    const life = parseFloat(document.getElementById('dep-life').value);
    const method = document.getElementById('dep-method').value;
    const resultDiv = document.getElementById('dep-result');

    if (isNaN(cost) || isNaN(salvage) || isNaN(life) || cost < 0 || salvage < 0 || life < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    if (life === 0) {
        showError(resultDiv, 'Useful life must be greater than 0');
        return;
    }

    let annualDepreciation = 0;
    let depreciableBase = cost - salvage;

    if (method === 'straight-line') {
        annualDepreciation = depreciableBase / life;
        showSuccess(resultDiv, `
            <table class="result-table">
                <tr>
                    <td>Asset Cost</td>
                    <td>$${cost.toFixed(2)}</td>
                </tr>
                <tr>
                    <td>Salvage Value</td>
                    <td>$${salvage.toFixed(2)}</td>
                </tr>
                <tr>
                    <td>Depreciable Base</td>
                    <td>$${depreciableBase.toFixed(2)}</td>
                </tr>
                <tr>
                    <td>Useful Life</td>
                    <td>${life.toFixed(2)} years</td>
                </tr>
                <tr>
                    <td>Method</td>
                    <td>Straight Line</td>
                </tr>
                <tr>
                    <td>Annual Depreciation</td>
                    <td><strong>$${annualDepreciation.toFixed(2)}</strong></td>
                </tr>
                <tr>
                    <td>Total Depreciation</td>
                    <td><strong>$${depreciableBase.toFixed(2)}</strong></td>
                </tr>
            </table>
        `);
    } else {
        // Declining Balance Method (20% declining rate)
        const declineRate = 0.2;
        annualDepreciation = cost * declineRate;
        const endValue = cost * Math.pow(1 - declineRate, life);

        showSuccess(resultDiv, `
            <table class="result-table">
                <tr>
                    <td>Asset Cost</td>
                    <td>$${cost.toFixed(2)}</td>
                </tr>
                <tr>
                    <td>Salvage Value</td>
                    <td>$${salvage.toFixed(2)}</td>
                </tr>
                <tr>
                    <td>Useful Life</td>
                    <td>${life.toFixed(2)} years</td>
                </tr>
                <tr>
                    <td>Decline Rate</td>
                    <td>20% per year</td>
                </tr>
                <tr>
                    <td>Method</td>
                    <td>Declining Balance</td>
                </tr>
                <tr>
                    <td>First Year Depreciation</td>
                    <td><strong>$${annualDepreciation.toFixed(2)}</strong></td>
                </tr>
                <tr>
                    <td>Estimated End Value</td>
                    <td><strong>$${endValue.toFixed(2)}</strong></td>
                </tr>
            </table>
        `);
    }
}

// SIP Calculator
function calculateSIP() {
    const monthlyAmount = parseFloat(document.getElementById('sip-amount').value);
    const annualReturn = parseFloat(document.getElementById('sip-return').value);
    const years = parseFloat(document.getElementById('sip-years').value);
    const resultDiv = document.getElementById('sip-result');

    if (isNaN(monthlyAmount) || isNaN(annualReturn) || isNaN(years) || 
        monthlyAmount < 0 || annualReturn < 0 || years < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    const monthlyRate = annualReturn / 100 / 12;
    const months = years * 12;
    const totalInvested = monthlyAmount * months;

    let maturityValue = 0;
    if (monthlyRate === 0) {
        maturityValue = totalInvested;
    } else {
        maturityValue = monthlyAmount * (((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate));
    }

    const gains = maturityValue - totalInvested;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Monthly Investment</td>
                <td>$${monthlyAmount.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Expected Annual Return</td>
                <td>${annualReturn.toFixed(2)}%</td>
            </tr>
            <tr>
                <td>Investment Period</td>
                <td>${years.toFixed(2)} years</td>
            </tr>
            <tr>
                <td>Total Invested Amount</td>
                <td>$${totalInvested.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Investment Gains</td>
                <td>$${gains.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Maturity Value</td>
                <td><strong>$${maturityValue.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// GST Calculator
function calculateGST() {
    const amount = parseFloat(document.getElementById('gst-amount').value);
    const gstRate = parseFloat(document.getElementById('gst-rate').value);
    const resultDiv = document.getElementById('gst-result');

    if (isNaN(amount) || isNaN(gstRate) || amount < 0 || gstRate < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    const gstAmount = (amount * gstRate) / 100;
    const totalAmount = amount + gstAmount;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Original Amount</td>
                <td>$${amount.toFixed(2)}</td>
            </tr>
            <tr>
                <td>GST Rate</td>
                <td>${gstRate.toFixed(2)}%</td>
            </tr>
            <tr>
                <td>GST Amount</td>
                <td><strong>$${gstAmount.toFixed(2)}</strong></td>
            </tr>
            <tr>
                <td>Total Amount (with GST)</td>
                <td><strong>$${totalAmount.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// Discount Calculator
function calculateDiscount() {
    const originalPrice = parseFloat(document.getElementById('disc-original').value);
    const discountPercent = parseFloat(document.getElementById('disc-percentage').value);
    const resultDiv = document.getElementById('disc-result');

    if (isNaN(originalPrice) || isNaN(discountPercent) || originalPrice < 0 || discountPercent < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    if (discountPercent > 100) {
        showError(resultDiv, 'Discount percentage cannot exceed 100%');
        return;
    }

    const discountAmount = (originalPrice * discountPercent) / 100;
    const finalPrice = originalPrice - discountAmount;
    const savings = discountAmount;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Original Price</td>
                <td>$${originalPrice.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Discount Percentage</td>
                <td>${discountPercent.toFixed(2)}%</td>
            </tr>
            <tr>
                <td>Discount Amount</td>
                <td>$${discountAmount.toFixed(2)}</td>
            </tr>
            <tr>
                <td>You Save</td>
                <td><strong>$${savings.toFixed(2)}</strong></td>
            </tr>
            <tr>
                <td>Final Price</td>
                <td><strong>$${finalPrice.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// Tax Calculator
function calculateTax() {
    const income = parseFloat(document.getElementById('tax-income').value);
    const bracket = document.getElementById('tax-bracket').value;
    const deductions = parseFloat(document.getElementById('tax-deductions').value);
    const resultDiv = document.getElementById('tax-result');

    if (isNaN(income) || isNaN(deductions) || income < 0 || deductions < 0) {
        showError(resultDiv, 'Please enter valid numbers');
        return;
    }

    const taxableIncome = income - deductions;
    let taxRate = 0;
    let taxBracketName = '';

    switch(bracket) {
        case 'bracket1':
            taxRate = 0.10;
            taxBracketName = '10% (0 - $10,000)';
            break;
        case 'bracket2':
            taxRate = 0.12;
            taxBracketName = '12% ($10,001 - $40,000)';
            break;
        case 'bracket3':
            taxRate = 0.22;
            taxBracketName = '22% ($40,001 - $85,000)';
            break;
        case 'bracket4':
            taxRate = 0.24;
            taxBracketName = '24% ($85,001 - $163,000)';
            break;
        case 'bracket5':
            taxRate = 0.32;
            taxBracketName = '32% ($163,001 - $207,350)';
            break;
        case 'bracket6':
            taxRate = 0.35;
            taxBracketName = '35% ($207,351 - $518,400)';
            break;
        case 'bracket7':
            taxRate = 0.37;
            taxBracketName = '37% (Over $518,400)';
            break;
    }

    const taxAmount = taxableIncome > 0 ? taxableIncome * taxRate : 0;
    const netIncome = income - taxAmount;
    const effectiveTaxRate = income > 0 ? (taxAmount / income) * 100 : 0;

    showSuccess(resultDiv, `
        <table class="result-table">
            <tr>
                <td>Annual Income</td>
                <td>$${income.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Deductions</td>
                <td>$${deductions.toFixed(2)}</td>
            </tr>
            <tr>
                <td>Taxable Income</td>
                <td>$${Math.max(0, taxableIncome).toFixed(2)}</td>
            </tr>
            <tr>
                <td>Tax Bracket</td>
                <td>${taxBracketName}</td>
            </tr>
            <tr>
                <td>Tax Amount</td>
                <td><strong>$${taxAmount.toFixed(2)}</strong></td>
            </tr>
            <tr>
                <td>Effective Tax Rate</td>
                <td>${effectiveTaxRate.toFixed(2)}%</td>
            </tr>
            <tr>
                <td>Net Income (After Tax)</td>
                <td><strong>$${netIncome.toFixed(2)}</strong></td>
            </tr>
        </table>
    `);
}

// Helper functions
function showError(element, message) {
    element.innerHTML = message;
    element.className = 'result error';
}

function showSuccess(element, message) {
    element.innerHTML = message;
    element.className = 'result success';
}